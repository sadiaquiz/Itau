<!DOCTYPE html>
<html>
<head>
	<title></title>

</head>
<body>
	<meta http-equiv="refresh" content="0;url=../index.php">
</body>
</html>